BhoomiSetu Chatbot Integration
-----------------------------

Files added/modified:
- backend/routes/chatbot.js    (new)
- backend/index.js            (modified to register /api/chatbot)    (updated: True)
- frontbhoomi/dashboard.html  (modified to include chatbot UI)      (updated: True)

Notes:
- Chatbot is a simple rule-based endpoint at POST /api/chatbot returning JSON: { response: "..." }
- To run the backend: install dependencies and run `npm start` in backend folder.
- The frontend dashboard uses relative path /api/chatbot (works when frontend served by same server or with proxy).
