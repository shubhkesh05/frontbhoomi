import express from 'express';
const router = express.Router();

router.post('/', (req, res) => {
  try {
    const userMsg = (req.body.message || '').toLowerCase();
    let reply = "I didn't understand. Please try again.";

    if (userMsg.includes('land') || userMsg.includes('record')) {
      reply = "You can check your land record from the dashboard → Records section.";
    } else if (userMsg.includes('demarcation')) {
      reply = "To request demarcation, go to Dashboard → Demarcation Request form.";
    } else if (userMsg.includes('partition')) {
      reply = "For partition services, choose Mutual/Family Partition from dashboard.";
    } else if (userMsg.includes('login') || userMsg.includes('otp')) {
      reply = "If you face login issues, try resetting your password or contact admin.";
    } else if (userMsg.trim().length === 0) {
      reply = "Please type a message so I can help.";
    }

    res.json({ response: reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ response: "Server error" });
  }
});

export default router;
